(function(window, undefined) {

  var jimLinks = {
    "10fa87a5-7738-421a-82bd-08e22fbd2e14" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);