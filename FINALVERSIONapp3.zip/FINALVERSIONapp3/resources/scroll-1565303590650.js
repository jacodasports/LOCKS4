(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimUtil, {
        "loadScrollBars": function() {
            jQuery(".s-10fa87a5-7738-421a-82bd-08e22fbd2e14 #s-Panel_1 .layoutWrapper").overscroll({ showThumbs:true, direction:'multi', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-10fa87a5-7738-421a-82bd-08e22fbd2e14 #s-Panel_23 .layoutWrapper").overscroll({ showThumbs:false, direction:'multi', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-10fa87a5-7738-421a-82bd-08e22fbd2e14 #s-Panel_24 .layoutWrapper").overscroll({ showThumbs:false, direction:'multi', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);